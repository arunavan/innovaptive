import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  userName: string;
  password: string;
  loginSuccess = false;
  loginFailed = false;

  login() {
    this.loginFailed = this.loginSuccess = false;
    console.log(this.userName, this.password);
    if (this.userName == "admin" && this.password == "admin@123") {
      this.loginSuccess = true
    } else {
      this.loginFailed = true;
    }
  }
}

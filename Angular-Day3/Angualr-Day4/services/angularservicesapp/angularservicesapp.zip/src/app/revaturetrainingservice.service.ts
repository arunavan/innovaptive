import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RevaturetrainingserviceService {

  constructor() { }

  gettrainingschedule() {
    return "every  month 1 week ";
  }
}

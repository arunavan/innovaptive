describe('first testcase ', () => {
    it('true is true', () => {
   expect(true).toEqual(true);    
    });

    it('Number test', () => {
        number:Number
        expect(10).toEqual(15);    
         });
     


  });
  
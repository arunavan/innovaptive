
/*
import { Component,ViewChild, AfterViewInit } from '@angular/core';
import { HelloComponent } from './hello/hello.component';
@Component({
  selector: 'app-root',
  template: `
     <h1> from parent {{ parentMessage }} </h1>
    <app-hello [x]="parentMessage"></app-hello>
    
  `,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  parentMessage = " using @input Message from Parent to Child ";
  constructor() { }
 
}
*/

import { Component } from '@angular/core';
//import { HelloComponent } from './hello/hello.component';
@Component({
  selector: 'app-root',
  template: `
    Message from Parent : {{m}}
    <app-child (x)="receiveMessage($event)"></app-child>
  `,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor() { }
  m:string;
  receiveMessage($event:any) {
    this.m = $event
  }
}

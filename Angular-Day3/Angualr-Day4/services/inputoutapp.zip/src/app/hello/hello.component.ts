/*
import { Component, Input } from '@angular/core';
@Component({
  selector: 'app-hello',
  template: ` <p>hello works!</p>
      Say from Child component {{ x }}
  `,
  styleUrls: ['./hello.component.css']
})
export class HelloComponent {
  @Input() x: string;
  constructor() { }



}

*/
import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  template: `
   <h2> Message in child : {{ m }} </h2>
      <button (click)="sendMessage()">Send Message</button>
  `,
  styleUrls: ['./hello.component.css']
})
export class HelloComponent {

  m: string = "Welcome to Angular Training! using @output -Child to Parent"

  @Output() x = new EventEmitter<string>();

  constructor() { }

  sendMessage() {
    this.x.emit(this.m)
  }
}


import { Component, OnInit } from '@angular/core';
import { IEmployee } from '../i-employee';
import { SEmployeeService } from '../s-employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  empId = "";
  empName = "";
  empEmail = "";
  empPhone = "";
  constructor(private employeeService: SEmployeeService,private router: Router) { }

  ngOnInit() {
    if(!this.employeeService.getSetEmployees())
    {
      this.employeeService.getEmployeesInitially().subscribe((employeesFetched)=>{
      this.employeeService.setEmployeesInitially(employeesFetched);
      },(error)=>console.log(error));
    }
    
  }

  onSubmit(employeeToBeAdded:IEmployee):void{
    this.employeeService.addEmployee(employeeToBeAdded).subscribe(employeeadded=>console.log(employeeadded));
      this.router.navigate(['/listemp']);
  }

}

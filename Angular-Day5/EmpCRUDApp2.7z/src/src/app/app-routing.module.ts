import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { ListEmployeesComponent } from './list-employees/list-employees.component';
import { FetchEmpIdComponent } from './fetch-emp-id/fetch-emp-id.component';


const routes: Routes = [
{path:'addemp',component:AddEmployeeComponent},
{path:'updateemp',component:UpdateEmployeeComponent},
{path:'listemp',component:ListEmployeesComponent},
{path:'fetchById',component:FetchEmpIdComponent},
{path:'',component:ListEmployeesComponent},
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

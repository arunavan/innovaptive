import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { ListEmployeesComponent } from './list-employees/list-employees.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { SEmployeeService } from './s-employee.service';
import {FormsModule} from '@angular/forms';
import { FetchEmpIdComponent } from './fetch-emp-id/fetch-emp-id.component'
@NgModule({
  declarations: [
    AppComponent,
    AddEmployeeComponent,
    UpdateEmployeeComponent,
    ListEmployeesComponent,
    FetchEmpIdComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,FormsModule
  ],
  providers: [HttpClient,SEmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }

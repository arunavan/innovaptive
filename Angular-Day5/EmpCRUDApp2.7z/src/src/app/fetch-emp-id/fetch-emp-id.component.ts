import { Component, OnInit } from '@angular/core';
import { SEmployeeService } from '../s-employee.service';

@Component({
  selector: 'app-fetch-emp-id',
  templateUrl: './fetch-emp-id.component.html',
  styleUrls: ['./fetch-emp-id.component.css']
})
export class FetchEmpIdComponent implements OnInit {

  constructor(private empService: SEmployeeService) { }

  ngOnInit() {
  }
fetchEmployee(eid:number)
{
  this.empService.getEmployeeById(eid).subscribe(data=>console.log(data))
}
}

import { Component, OnInit } from '@angular/core';
import { IEmployee } from '../i-employee';
import { SEmployeeService } from '../s-employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-employees',
  templateUrl: './list-employees.component.html',
  styleUrls: ['./list-employees.component.css']
})
export class ListEmployeesComponent implements OnInit {

  employees: IEmployee[];
  
  constructor(private empService: SEmployeeService,private router: Router) { }

  ngOnInit() {
    this.getEmployees();
  }
  onDelete(deletedEmployee: IEmployee){
    this.empService.onDeleteEmployee(deletedEmployee); //deleting the employee
  }
  onUpdate(updatedEmployee: IEmployee){
    this.router.navigate(['/updateemp']); //updating the employee
  }
  
  getEmployees() {
     //adding employees or getting data of employees
    if(!this.empService.getSetEmployees())
    {
      this.empService.getEmployeesInitially().subscribe((employeesFetched)=>{
      this.employees = employeesFetched;
      this.empService.setEmployeesInitially(this.employees);
      },(error)=>console.log(error));
    }
    {
      this.employees=this.empService.getSetEmployees();
    }
  }

}

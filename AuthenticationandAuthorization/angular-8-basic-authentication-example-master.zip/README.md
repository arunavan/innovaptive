# angular-8-basic-authentication-example

Angular 8 - Basic HTTP Authentication Example with Angular CLI

For a demo and further details see https://jasonwatmore.com/post/2019/06/26/angular-8-basic-http-authentication-tutorial-example
	const db = require('./db')  
	const Query = {  
	   hello:() => {  
	      return "Welcome to GraphQL..."  
	   },  
	   employees:() => db.employees.list()  ,
           companies:() =>db.companies.list()
	}  
	module.exports = {Query}  

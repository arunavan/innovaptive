const { ApolloServer, gql } = require('apollo-server');  

const typeDefs = gql`
type Query  {
   greeting: String
}`;

const  resolvers = {
   Query : {
      greeting: () => 'Welcome to  GraphQL/innovapptive   !!'
   }
}

const server = new ApolloServer({ typeDefs, resolvers });  
server.listen().then(({ url }) => {  
  console.log(`Server ready at ${url}`);  //default 4000
});  



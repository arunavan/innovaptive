
const { ApolloServer } = require('apollo-server');  
const { PubSub }=require("graphql-subscriptions");
const typeDefs = require("./typeDefs");
const resolvers = require("./resolvers");
const pubsub = new PubSub();

const server = new ApolloServer({
  typeDefs,
  resolvers,
  context: {
    pubsub,
  },
});



server.listen().then(({ url }) => {  
	  console.log(`Server ready 4000  default`);  
	});  
/*
server.start(options, ({ port }) => {
  console.log(
    `Graphql Server started, listening on port ${port} for incoming requests.`
  );
});
*/

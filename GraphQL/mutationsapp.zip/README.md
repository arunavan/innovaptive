

npm install


Start the application using the following command 


node server.js


The application runs on **localhost:5000/graphql**


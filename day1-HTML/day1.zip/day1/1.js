<!--
=============save this file as 1.js

function validate()
 {  var x=document.f.p1.value.length;
    if (x>6)
       alert("id should be below 6 chars");
    if(document.f.p2.value.length>4)
       alert("password should be below 4 chars");
  
  }
================
--> create static webpages
 ->format the elements
-> embed images
-> dynamic content
-> event handling
-> forms ,tables ,list
-> frameset complex  

    
<html>
<head>
	<script src="1.js">
</script>
</head>

<body>
<script>
  sum(5,6)
</script>
</body>
</html>




function sum(a,b)
{
   var sum=parseInt(a)+parseInt(b);
   alert("Sum="+sum);

}



















